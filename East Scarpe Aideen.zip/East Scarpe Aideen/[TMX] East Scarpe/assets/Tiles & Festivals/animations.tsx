<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="animations" tilewidth="16" tileheight="16" tilecount="8320" columns="40">
 <image source="../../../../Desktop/xnbcli/unpacked/animations.png" width="640" height="3328"/>
</tileset>
