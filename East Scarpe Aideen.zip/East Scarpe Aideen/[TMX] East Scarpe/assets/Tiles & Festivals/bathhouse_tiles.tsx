<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="bathhouse_tiles" tilewidth="16" tileheight="16" tilecount="240" columns="15">
 <image source="bathhouse_tiles.png" width="240" height="256"/>
</tileset>
